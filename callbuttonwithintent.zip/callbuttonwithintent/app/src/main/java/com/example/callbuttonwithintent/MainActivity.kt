package com.example.callbuttonwithintent

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("AppData", MODE_PRIVATE)

        // UI Elements
        val etName: EditText = findViewById(R.id.et_name)
        val etMobile: EditText = findViewById(R.id.et_mobile)
        val btnCall: Button = findViewById(R.id.btn_call)

        // Restore saved data
        etName.setText(sharedPreferences.getString("name", ""))
        etMobile.setText(sharedPreferences.getString("mobile", ""))

        btnCall.setOnClickListener {
            val name = etName.text.toString().trim()
            val mobile = etMobile.text.toString().trim()

            if (name.isEmpty() || mobile.isEmpty()) {
                Toast.makeText(this, "Please enter both Name and Mobile Number", Toast.LENGTH_SHORT).show()
            } else {
                // Save data for future use
                val editor = sharedPreferences.edit()
                editor.putString("name", name)
                editor.putString("mobile", mobile)
                editor.apply()

                // Show Toast
                Toast.makeText(this, "Calling $name", Toast.LENGTH_SHORT).show()

                // Open Dialer
                try {
                    val intent = Intent(Intent.ACTION_DIAL).apply {
                        data = Uri.parse("tel:$mobile")
                    }
                    startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(this, "No dialer app found!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("name", findViewById<EditText>(R.id.et_name).text.toString())
        outState.putString("mobile", findViewById<EditText>(R.id.et_mobile).text.toString())
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        findViewById<EditText>(R.id.et_name).setText(savedInstanceState.getString("name", ""))
        findViewById<EditText>(R.id.et_mobile).setText(savedInstanceState.getString("mobile", ""))
    }
}
